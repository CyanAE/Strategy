"""
展示如何执行策略回测。
"""
from vnpy.trader.app.ctaStrategy import BacktestingEngine
import pandas as pd
from vnpy.trader.utils import htmlplot
import json
import os
from RegressionStrategy import RegressionStrategy

# hhh = ['T88:CTP', 'AL88:CTP', 'ZC88:CTP', 'FU88:CTP', 'C88:CTP', 'B88:CTP', 'JR88:CTP', 'NI88:CTP', 'SR88:CTP', 'eos.usd.q:okef', 'CU88:CTP', 'I88:CTP', 'BB88:CTP', 'FB88:CTP', 'JM88:CTP', 'TF88:CTP', 'PM88:CTP', 'PB88:CTP', 'JD88:CTP', 'RB88:CTP', 'CS88:CTP', 'AG88:CTP', 'HC88:CTP', 'WH88:CTP', 'SF88:CTP', 'J88:CTP', 'SM88:CTP', 'IH88:CTP', 'LR88:CTP', 'AU88:CTP', 'V88:CTP', 'SC88:CTP', 'BU88:CTP', 'L88:CTP', 'RI88:CTP', 'A88:CTP', 'PP88:CTP', 'IC88:CTP', 'RM88:CTP', 'TA88:CTP', 'ZN88:CTP', 'OI88:CTP', 'FG88:CTP', 'M88:CTP', 'WR88:CTP', 'CF88:CTP', 'P88:CTP', 'Y88:CTP', 'RU88:CTP', 'SN88:CTP', 'IF88:CTP', 'RS88:CTP', 'btc.usd.q:okef', 'MA88:CTP']
# x = 0
# for x in range(52):
if __name__ == '__main__':
    # 创建回测引擎
    engine = BacktestingEngine()
    engine.setDB_URI("mongodb://localhost:27017")
    # engine.setDB_URI("mongodb://192.168.4.132:27017")

    # Bar回测
    engine.setBacktestingMode(engine.BAR_MODE)
    engine.setDatabase('VnTrader_1Min_Db')

    # Tick回测
    # engine.setBacktestingMode(engine.TICK_MODE)
    # engine.setDatabase('VnTrader_1Min_Db', 'VnTrader_Tick_Db')

    # 设置回测用的数据起始日期，initHours 默认值为 0
    # engine.setStartDate('20180201 23:00:00',initHours=10)
    # engine.setStartDate('20180202 10:00:00',initHours=10)
    engine.setStartDate('20181130 10:00:00',initHours=10)
    engine.setEndDate('20190320 23:00:00')

    # 设置产品相关参数
    engine.setCapital(1000000)  # 设置起始资金，默认值是1,000,000
    contracts = [{
                    "symbol":"RU88:CTP",
                    "size" : 1, # 每点价值
                    "priceTick" : 0.2, # 最小价格变动
                    "rate" : 5/10000, # 单边手续费
                    "slippage" : 0.1 # 滑价
                    },] 

    engine.setContracts(contracts)
    engine.setLog(True, "./logIF88")
    # 获取当前绝对路径
    path = os.path.split(os.path.realpath(__file__))[0]
    with open(path+"//CTA_setting.json") as f:
        setting = json.load(f)[0]

    # Bar回测
    engine.initStrategy(RegressionStrategy, setting)
    
    # 开始跑回测
    engine.runBacktesting()
    
    # 显示回测结果
    engine.showBacktestingResult()
    engine.showDailyResult()
    
    # if __name__ == '__main__':
    #     # 创建回测引擎
    #     engine = BacktestingEngine()
    #     engine.setDB_URI("mongodb://localhost:27017")
    #     # engine.setDB_URI("mongodb://192.168.4.132:27017")

    #     # Bar回测
    #     engine.setBacktestingMode(engine.BAR_MODE)
    #     engine.setDatabase('VnTrader_1Min_Db')

    #     # Tick回测
    #     # engine.setBacktestingMode(engine.TICK_MODE)
    #     # engine.setDatabase('VnTrader_1Min_Db', 'VnTrader_Tick_Db')

    #     # 设置回测用的数据起始日期，initHours 默认值为 0
    #     # engine.setStartDate('20180201 23:00:00',initHours=10)
    #     engine.setStartDate('20180202 10:00:00',initHours=10)
    #     # engine.setStartDate('20181130 10:00:00',initHours=10)
    #     engine.setEndDate('20190320 23:00:00')

    #     # 设置产品相关参数
    #     engine.setCapital(1000000)  # 设置起始资金，默认值是1,000,000
    #     contracts = [{
    #                     "symbol":"FB88:CTP",
    #                     "size" : 1, # 每点价值
    #                     "priceTick" : 0.1, # 最小价格变动
    #                     "rate" : 5/10000, # 单边手续费
    #                     "slippage" : 0.1 # 滑价
    #                     },] 

    #     engine.setContracts(contracts)
    #     engine.setLog(True, "./logIF88")
    #     # 获取当前绝对路径
    #     path = os.path.split(os.path.realpath(__file__))[0]
    #     with open(path+"//CTA_setting.json") as f:
    #         setting = json.load(f)[0]

    #     # Bar回测
    #     engine.initStrategy(RegressionStrategy, setting)
        
    #     # 开始跑回测
    #     engine.runBacktesting()
        
    #     # 显示回测结果
    #     engine.showBacktestingResult()
        # engine.showDailyResult()
        
        ### 画图分析
        # chartLog = pd.DataFrame(engine.strategy.chartLog).set_index('datetime')
        # mp = htmlplot.getMultiPlot(engine, freq="15m")
        # mp.addLine(line=chartLog[['residualSma', 'residualLma']].reset_index(), colors={'residualSma': "red",'residualLma':'blue'}, pos=0)
        # mp.resample()
        # mp.show()
    # x = x + 1
