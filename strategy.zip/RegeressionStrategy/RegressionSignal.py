import talib as ta
import numpy as np
import pandas as pd

"""
将kdj策略需要用到的信号生成器抽离出来
"""

class maSignal():

    def __init__(self):
        self.author = 'Cyan'

    def maEnvironment(self, am, paraDict):
        envPeriod = paraDict["envPeriod"]

        envMa = ta.MA(am.close, envPeriod)
        envDirection = 1 if am.close[-1]>envMa[-1] else -1
        return envDirection, envMa

    def Cross(self,am,paraDict):
        regPeriod = paraDict["regPeriod"]
        residualLmaPeriod = paraDict["residualLmaPeriod"]
        residualSmaPeriod = paraDict["residualSmaPeriod"]
        
        prediction = ta.LINEARREG(am.close, regPeriod)
        residual = (am.close - prediction) / am.close
        residualSma = ta.MA(residual, residualSmaPeriod)
        residualLma = ta.MA(residual, residualLmaPeriod) 
        # sma = ta.MA(am.close, fastPeriod)
        # lma = ta.MA(am.close, slowPeriod)
        residualUp = residualSma[-1] > residualLma[-1]
        residualDn = residualSma[-1] < residualLma[-1]
        # deathCross = sma[-1]<lma[-1] and sma[-2]>=lma[-2]

        CrossSignal = 0
        if residualUp:
            CrossSignal = 1
        elif residualDn:
            CrossSignal = -1
        else:
            CrossSignal = 0
        return CrossSignal, residualSma, residualLma
    
        